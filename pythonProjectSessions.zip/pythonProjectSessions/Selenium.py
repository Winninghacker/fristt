import time
from selenium import webdriver
from selenium.webdriver.common.by import By

#launch the driver or the website


driver = webdriver.Chrome("C:\\Users\\piyushdhamne\\PycharmProjects\\pythonProjectSessions\\drivers\\chromedriver.exe")
driver.get("https://courses.letskodeit.com/practice")

print("Title is: " + driver.title)


driver.implicitly_wait(5)

#Locating by id
elementId = driver.find_element(By.ID, "alert-example-div")
if elementId is not None:
    print("Id Element Found")

#Locating by xpath
elementId = driver.find_element(By.XPATH,"//div[@id='alert-example-div']")
if elementId is not None:
    print("Xpath Element Found")

#Locating by Name
elementName = driver.find_element(By.NAME, "enter-name")
if elementName is not None:
   print("Name Elements Found")
elementName.send_keys("Piyush")

elementsByTabgName = driver.find_elements(By.TAG_NAME,"a")
countOflinks =  len(elementsByTabgName)

print(f"The number of Links: " + str(countOflinks))
time.sleep(5)
driver.close()
