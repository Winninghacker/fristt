def test_smokeTestCase1():
    assert [2,3] == [2, 3]

def test_smokeTestcase2():
    assert 2 + 2 == 5

def test_smokeTestcase3():
    assert "Hello Nagarr" == "Hello Nagarro"

