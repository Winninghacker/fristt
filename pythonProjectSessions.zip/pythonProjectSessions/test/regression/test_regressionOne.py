def test_regressionTestcase1():
    assert [2,3] == [2, 3]

def test_regressionTestcase2():
    assert 2 + 2 == 5

def test_regressionTestcase3():
    assert "Hello Nagarro" == "Hello Nagarro"

