def nagarro_firstnagarroFifthTestCase():
    assert [2,3] == [2, 3]

def nagarro_firstnagarroSixthTestCase():
    assert 2 + 2 == 4