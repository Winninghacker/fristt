def test_firstthirdTestCase():
    assert [2,3] == [2, 3]

def test_secondfourthTestcase():
    assert 2 + 2 == 5