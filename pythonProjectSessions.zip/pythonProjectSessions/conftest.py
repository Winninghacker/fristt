from selenium.webdriver.chrome.options import Options
import config
from selenium import webdriver
# import fixture as fixture

# @fixture(scope="session")
def open_browser():
    global driver

    if config.mode.lower() == "non-headeless":
        if config.browser.lower() == 'chrome':
            driver = webdriver.Chrome(config.chrome_driver_dir_location)
            #return driver
        #driver
        elif config.browser.lower() == 'firefox':
            driver =  webdriver.Firefox(config.chrome_driver_dir_location)
            # return driver
        else:
            print("Browser name in config is invalid")

    elif config.mode.lower() == "headless":
        if config.browser.lower() == 'chrome':
            options = Options()
            options.headless = True
            driver = webdriver.Chrome(config.chrome_driver_dir_location, options=options)
            #return driver
        elif config.browser.lower() == 'firefox':
            driver = webdriver.Firefox(config.firefox_driver_dir_location)
            #return driver
        else:
            print("Driver name in the config is invalid")

    driver.maximize_window()
    driver.delete_all_cookies()
    driver.get(config.base_Url)

    return driver